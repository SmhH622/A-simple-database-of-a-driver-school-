import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.*;
import java.util.*;

    
public class questionk extends JFrame {  
          

        Vector rowData,columnNames;  
        JTable jt=null;  
        JScrollPane jsp=null;  
          
      
        PreparedStatement ps=null;  
        Connection ct=null;  
        ResultSet rs=null;  
          
          
        public static void main(String[] args) {  
              
            questionk questionk=new questionk();  
      
        }  
      
            public questionk(){  
                  
                columnNames=new Vector();  
          
                columnNames.add("idcar");

                
                 
                  
                rowData = new Vector();  
                
                  
                 Connection con;
       
        String driver = "com.mysql.jdbc.Driver";
        
        String url = "jdbc:mysql://localhost:3306/easydrive_school";
       
        String user = "root";
      
        String password = "newpass";
         
          try {
           
            Class.forName(driver); 
           
            con = DriverManager.getConnection(url,user,password);
            if(!con.isClosed())
                System.out.println("Succeeded connecting to the Database!");
           
            Statement statement = con.createStatement();
                    ct=DriverManager.getConnection("jdbc:mysql://localhost:3306/easydrive_school","root","newpass");  
                      
                    ps=ct.prepareStatement("SELECT idCar FROM easydrive_school.car where Office_oName='Bearsden'");  
                      
                    rs=ps.executeQuery();  
                      
                    while(rs.next()){  
                      
                        Vector hang=new Vector();  
                        hang.add(rs.getString(1));


                       
                         
                     
                        rowData.add(hang);  
                    }  
                } catch (Exception e) {  
                    e.printStackTrace();  
                } finally{  
                      
                        try {  
                            if(rs!=null){  
                            rs.close();  
                            }  
                            if(ps!=null){  
                                ps.close();  
                            }  
                            if(ct!=null){  
                                ct.close();  
                            }  
                        } catch (SQLException e) {  
                            e.printStackTrace();  
                        }  
                }  
                  
                              
            
                jt = new JTable(rowData,columnNames);  
                  
             
                jsp = new JScrollPane(jt);  
                  
             
                this.add(jsp);  
                  
                this.setSize(400, 300);  
                  
                this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);   
                this.setVisible(true);  
                this.setLocation(700,200); 
            }} 