import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.*;
import java.util.*;

    
public class client extends JFrame {  
          

        Vector rowData,columnNames;  
        JTable jt=null;  
        JScrollPane jsp=null;  
          
        PreparedStatement ps=null;  
        Connection ct=null;  
        ResultSet rs=null;  
         /* 
           public static void main(String[] args) {  
              
            client ppp=new client("Von","Naldo");    //for test
      
        } */ 
        
  
            public client(String str1,String str2){  
                  
                columnNames=new Vector();            
                columnNames.add("idclient");
                columnNames.add("fName");
                columnNames.add("sName");
                columnNames.add("sex");
                columnNames.add("DoB");
                columnNames.add("telNo");
                columnNames.add("File_idFile");
                columnNames.add("office_oName");


                
                 
                  
                rowData = new Vector();  
               
                  
                 Connection con;
      
        String driver = "com.mysql.jdbc.Driver";
        
        String url = "jdbc:mysql://localhost:3306/easydrive_school";
        
        String user = "root";
        
        String password = "newpass";
         
          try {
            
            Class.forName(driver); 
            
            con = DriverManager.getConnection(url,user,password);
            if(!con.isClosed())
                System.out.println("Succeeded connecting to the Database!");
            
            Statement statement = con.createStatement();
                    ct=DriverManager.getConnection("jdbc:mysql://localhost:3306/easydrive_school","root","newpass");  
                    String str0=("select * from easydrive_school.client where fName = '");
                    str0=str0+str1+"' and sName = '"+str2+"';";
                    
                    ps=ct.prepareStatement(str0); 
                    
                      
                    rs=ps.executeQuery();  
                      
                    while(rs.next()){  
                       
                        Vector hang=new Vector();  
                        hang.add(rs.getString(1));
                        hang.add(rs.getString(2));
                        hang.add(rs.getString(3));
                        hang.add(rs.getString(4));
                        hang.add(rs.getString(5));
                        hang.add(rs.getString(6));
                        hang.add(rs.getString(7));
                        hang.add(rs.getString(8));
                                               
                         
                      
                        rowData.add(hang);  
                    }  
                } catch (Exception e) {  
                    e.printStackTrace();  
                } finally{  
                      
                        try {  
                            if(rs!=null){  
                            rs.close();  
                            }  
                            if(ps!=null){  
                                ps.close();  
                            }  
                            if(ct!=null){  
                                ct.close();  
                            }  
                        } catch (SQLException e) {  
                            e.printStackTrace();  
                        }  
                }  
                  
                              
               
                jt = new JTable(rowData,columnNames);  
                  
                
                jsp = new JScrollPane(jt);  
                  
              
                this.add(jsp);  
                  
                this.setSize(1000, 300);  
                  
                this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);  
                this.setVisible(true);  
                this.setLocation(200,200);
            }} 